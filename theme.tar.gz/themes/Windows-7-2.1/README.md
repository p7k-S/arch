[![built-with-azurra-framework](https://github.com/Elbullazul/Azurra_framework/raw/assets/azurra_framework_smaller.png)](https://github.com/Elbullazul/Azurra_framework)

# Windows 7

Linux theme based on the apperance of Windows 7

![win-7](https://b00merang.weebly.com/uploads/1/6/8/1/16813022/906611131-orig-orig_2_orig.png)

**Maintainer :** [Elbullazul](https://github.com/Elbullazul)

**Distributor :** [B00merang Project](https://github.com/B00merang-Project)

**License :** GPL v3

**More info :** http://b00merang.weebly.com/windows-7.html

### Manual installation

Extract the zip file to the themes directory i.e. `/home/USERNAME/.themes`

### Requirements

- GTK+ 3.20 or above
- Murrine and Pixmap theme engines

### Contribute

Contact us @ http://b00merang.weebly.com/contact.html
